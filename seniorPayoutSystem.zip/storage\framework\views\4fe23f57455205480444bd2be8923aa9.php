<?php $__env->startSection('topbar-title', 'Barangays'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-head">
    <div>
        <div class="page-eyebrow">Records</div>
        <h2 class="page-title">Barangays</h2>
        <div class="page-sub">Service-area barangays and senior counts.</div>
    </div>
    <div class="page-actions">
        <?php if(auth()->user()->role === 'admin'): ?>
        <a href="<?php echo e(route('barangays.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> Add barangay
        </a>
        <?php endif; ?>
    </div>
</div>

<div class="table-wrap">
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>City</th>
                <th class="text-end">Seniors</th>
                <th class="text-end">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $barangays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barangay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-muted"><?php echo e($barangay->id); ?></td>
                    <td class="fw-semibold"><?php echo e($barangay->name); ?></td>
                    <td><?php echo e($barangay->city); ?></td>
                    <td class="text-end">
                        <span class="pill pill-muted"><?php echo e($barangay->seniors()->count()); ?></span>
                    </td>
                    <td class="text-end">
                        <div class="row-actions">
                            <a href="<?php echo e(route('barangays.show', $barangay)); ?>"
                                class="row-action view" title="View">
                                <i class="bi bi-eye"></i>
                            </a>
                            <?php if(auth()->user()->role === 'admin'): ?>
                            <a href="<?php echo e(route('barangays.edit', $barangay)); ?>"
                                class="row-action edit" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="<?php echo e(route('barangays.destroy', $barangay)); ?>"
                                method="POST"
                                onsubmit="return confirm('Delete this barangay?')"
                                class="d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="row-action delete" title="Delete">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="table-empty">No barangays added yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-3">
    <?php echo e($barangays->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dell7\Documents\GitHub\seniorPayoutSystem\resources\views/barangays/index.blade.php ENDPATH**/ ?>