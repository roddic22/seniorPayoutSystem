<?php $__env->startSection('topbar-title', 'Senior details'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-head">
    <div>
        <div class="page-eyebrow"><a href="<?php echo e(route('seniors.index')); ?>" class="text-muted text-decoration-none">Seniors</a> / <?php echo e($senior->osca_id); ?></div>
        <h2 class="page-title"><?php echo e($senior->name); ?></h2>
        <div class="page-sub">OSCA ID <?php echo e($senior->osca_id); ?></div>
    </div>
    <div class="page-actions">
        <a href="<?php echo e(route('seniors.index')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left me-1"></i> Back
        </a>
        <a href="<?php echo e(route('seniors.edit', $senior)); ?>" class="btn btn-primary">
            <i class="bi bi-pencil me-1"></i> Edit
        </a>
    </div>
</div>

<div class="surface">
    <div class="surface-head">
        <h5>Profile</h5>
        <?php if($senior->status === 'active' || $senior->status === 'Active'): ?>
            <span class="pill pill-success">Active</span>
        <?php elseif($senior->status === 'inactive' || $senior->status === 'Inactive'): ?>
            <span class="pill pill-muted">Inactive</span>
        <?php elseif($senior->status === 'deceased' || $senior->status === 'Deceased'): ?>
            <span class="pill pill-danger">Deceased</span>
        <?php else: ?>
            <span class="pill pill-muted"><?php echo e(ucfirst($senior->status ?? '-')); ?></span>
        <?php endif; ?>
    </div>
    <div class="surface-body">
        <dl class="deflist">
            <dt>OSCA ID</dt><dd><?php echo e($senior->osca_id); ?></dd>
            <dt>Full name</dt><dd><?php echo e($senior->name); ?></dd>
            <dt>Age</dt><dd><?php echo e($senior->age); ?></dd>
            <dt>Birthdate</dt><dd><?php echo e($senior->birthdate ?? '-'); ?></dd>
            <dt>Sex</dt><dd><?php echo e($senior->sex ? ucfirst($senior->sex) : '-'); ?></dd>
            <dt>Contact</dt><dd><?php echo e($senior->contact_number ?? '-'); ?></dd>
            <dt>Address</dt><dd><?php echo e($senior->address); ?></dd>
            <dt>Barangay</dt><dd><?php echo e($senior->barangay->name ?? '-'); ?></dd>
        </dl>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dell7\Documents\GitHub\seniorPayoutSystem\resources\views/seniors/show.blade.php ENDPATH**/ ?>