<?php $__env->startSection('topbar-title', 'Payout cycles'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-head">
    <div>
        <div class="page-eyebrow">Payouts</div>
        <h2 class="page-title">Payout cycles</h2>
        <div class="page-sub">Disbursement periods configured for the program.</div>
    </div>
    <div class="page-actions">
        <?php if(auth()->user()->role === 'admin'): ?>
        <a href="<?php echo e(route('payout-cycles.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> New cycle
        </a>
        <?php endif; ?>
    </div>
</div>

<div class="table-wrap">
    <table class="table">
        <thead>
            <tr>
                <th>Cycle name</th>
                <th>Period start</th>
                <th>Period end</th>
                <th>Status</th>
                <th class="text-end">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $cycles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cycle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($cycle->cycle_name); ?></td>
                    <td><?php echo e($cycle->period_start); ?></td>
                    <td><?php echo e($cycle->period_end); ?></td>
                    <td>
                        <?php if($cycle->status === 'active'): ?>
                            <span class="pill pill-success">Active</span>
                        <?php elseif($cycle->status === 'draft'): ?>
                            <span class="pill pill-muted">Draft</span>
                        <?php else: ?>
                            <span class="pill pill-dark">Completed</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end">
                        <div class="row-actions">
                            <a href="<?php echo e(route('payout-cycles.show', $cycle)); ?>"
                                class="row-action view" title="View">
                                <i class="bi bi-eye"></i>
                            </a>
                            <?php if(auth()->user()->role === 'admin'): ?>
                            <a href="<?php echo e(route('payout-cycles.edit', $cycle)); ?>"
                                class="row-action edit" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="<?php echo e(route('payout-cycles.destroy', $cycle)); ?>"
                                method="POST"
                                onsubmit="return confirm('Delete this cycle?')"
                                class="d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="row-action delete" title="Delete">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="table-empty">No payout cycles configured yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-3">
    <?php echo e($cycles->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dell7\Documents\GitHub\seniorPayoutSystem\resources\views/payout-cycles/index.blade.php ENDPATH**/ ?>