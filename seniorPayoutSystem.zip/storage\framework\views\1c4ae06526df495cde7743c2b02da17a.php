<?php $__env->startSection('topbar-title', 'Transactions'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-head">
    <div>
        <div class="page-eyebrow">Payouts</div>
        <h2 class="page-title">Payout transactions</h2>
        <div class="page-sub">Disbursement records and claim status.</div>
    </div>
    <div class="page-actions">
        <a href="<?php echo e(route('payout-transactions.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> Record transaction
        </a>
    </div>
</div>

<div class="table-wrap">
    <table class="table">
        <thead>
            <tr>
                <th>Senior</th>
                <th>Cycle</th>
                <th>Counter</th>
                <th class="text-end">Amount</th>
                <th>Status</th>
                <th>Claimed at</th>
                <th class="text-end">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="fw-semibold"><?php echo e($transaction->senior->name ?? '—'); ?></td>
                    <td class="text-muted"><?php echo e($transaction->cycle->cycle_name ?? '—'); ?></td>
                    <td><?php echo e($transaction->counter->counter_number ?? '—'); ?></td>
                    <td class="text-end fw-semibold">₱<?php echo e(number_format($transaction->amount, 2)); ?></td>
                    <td>
                        <?php if($transaction->claim_status === 'claimed'): ?>
                            <span class="pill pill-success">Claimed</span>
                        <?php elseif($transaction->claim_status === 'unclaimed'): ?>
                            <span class="pill pill-warning">Unclaimed</span>
                        <?php else: ?>
                            <span class="pill pill-danger">Cancelled</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-muted"><?php echo e($transaction->claimed_at ?? '—'); ?></td>
                    <td class="text-end">
                        <div class="row-actions">
                            <a href="<?php echo e(route('payout-transactions.show', $transaction)); ?>" class="row-action view" title="View"><i class="bi bi-eye"></i></a>
                            <?php if(auth()->user()->role === 'admin'): ?>
                            <a href="<?php echo e(route('payout-transactions.edit', $transaction)); ?>" class="row-action edit" title="Edit"><i class="bi bi-pencil"></i></a>
                            <form action="<?php echo e(route('payout-transactions.destroy', $transaction)); ?>" method="POST"
                                onsubmit="return confirm('Delete this transaction?')" class="d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="row-action delete" title="Delete"><i class="bi bi-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="table-empty">No transactions recorded yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-3">
    <?php echo e($transactions->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dell7\Documents\GitHub\seniorPayoutSystem\resources\views/payout-transactions/index.blade.php ENDPATH**/ ?>