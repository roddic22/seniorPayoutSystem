<?php $__env->startSection('content'); ?>
<main class="login-screen">
    <section class="login-card">
        <div class="login-photo" aria-hidden="true"></div>

        <div class="login-panel">
            <div class="brand-row">
                <div class="brand-mark">
                    <i class="bi bi-shield-check"></i>
                </div>
                <div>
                    <div class="brand-name">SPS</div>
                    <div class="brand-sub">Senior Payout System</div>
                </div>
            </div>

            <h1>Welcome Back!</h1>
            <p class="login-copy">Please sign in using your provided account.</p>

            <?php if(session('error')): ?>
                <div class="alert alert-danger mb-3"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger mb-3"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('login.store')); ?>" autocomplete="off">
                <?php echo csrf_field(); ?>

                <div class="login-field">
                    <i class="bi bi-envelope"></i>
                    <input
                        type="email"
                        name="email"
                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('email')); ?>"
                        placeholder="Email address"
                        autocomplete="off"
                        required
                        autofocus
                    >
                </div>

                <div class="login-field">
                    <i class="bi bi-lock"></i>
                    <input
                        type="password"
                        name="password"
                        id="passwordInput"
                        class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        placeholder="Password"
                        autocomplete="new-password"
                        required
                    >
                    <button type="button" class="password-toggle" onclick="togglePw()" tabindex="-1" aria-label="Show password">
                        <i class="bi bi-eye" id="pwIcon"></i>
                    </button>
                </div>

                <button type="submit" class="login-submit">
                    <i class="bi bi-box-arrow-in-right"></i>
                    Sign in
                </button>
            </form>

            <div class="login-divider"></div>

            <div class="login-admin"></div>

            <div class="login-badges" aria-hidden="true">
                <span><i class="bi bi-bank"></i></span>
                <span><i class="bi bi-person-badge"></i></span>
                <span><i class="bi bi-patch-check"></i></span>
            </div>
        </div>
    </section>

    <footer class="login-footer">
        <div>Senior Payout System</div>
        <nav>
            <span>OSCA Support</span>
            <span>Payout Tracking</span>
            <span>Claims Portal</span>
        </nav>
    </footer>
</main>

<script>
function togglePw() {
    const input = document.getElementById('passwordInput');
    const icon  = document.getElementById('pwIcon');
    if (input.type === 'password') {
        input.type = 'text';
        icon.className = 'bi bi-eye-slash';
    } else {
        input.type = 'password';
        icon.className = 'bi bi-eye';
    }
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dell7\Documents\GitHub\seniorPayoutSystem\resources\views/auth/login.blade.php ENDPATH**/ ?>