<?php $__env->startSection('topbar-title', 'Dashboard'); ?>
<?php $__env->startSection('topbar-sub', 'System overview and analytics'); ?>

<?php $__env->startSection('content'); ?>

<?php if(auth()->user()?->role === 'staff'): ?>
    <div class="page-head">
        <div>
            <div class="page-eyebrow">Staff dashboard</div>
            <h2 class="page-title">Welcome, <?php echo e(auth()->user()->name); ?></h2>
            <div class="page-sub">Your assigned payout counter, schedule, and location.</div>
        </div>
    </div>

    <?php if($staffAssignments->isEmpty()): ?>
        <div class="surface">
            <div class="empty-state">
                <i class="bi bi-calendar-x d-block"></i>
                <h5 class="mb-1">Nothing at the moment</h5>
                <div>No counter or payout schedule has been assigned to you yet.</div>
            </div>
        </div>
    <?php else: ?>
        <div class="row g-3">
            <?php $__currentLoopData = $staffAssignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-6">
                    <div class="surface h-100">
                        <div class="surface-head">
                            <h5><i class="bi bi-person-badge me-2"></i><?php echo e(auth()->user()->name); ?></h5>
                            <span class="pill pill-info">Assigned</span>
                        </div>
                        <div class="surface-body">
                            <dl class="deflist">
                                <dt>Counter</dt>
                                <dd><?php echo e($assignment->counter->counter_number ?? '-'); ?></dd>

                                <dt>Scheduled date</dt>
                                <dd><?php echo e($assignment->schedule->scheduled_date ?? '-'); ?></dd>

                                <dt>Place</dt>
                                <dd><?php echo e($assignment->schedule->venue ?? '-'); ?></dd>

                                <dt>Barangay</dt>
                                <dd><?php echo e($assignment->schedule->barangay->name ?? '-'); ?></dd>

                                <dt>Time</dt>
                                <dd>
                                    <?php echo e($assignment->schedule->time_start ?? '-'); ?>

                                    <?php if($assignment->schedule?->time_end): ?>
                                        - <?php echo e($assignment->schedule->time_end); ?>

                                    <?php endif; ?>
                                </dd>

                                <dt>Payout cycle</dt>
                                <dd><?php echo e($assignment->schedule->cycle->cycle_name ?? '-'); ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
<?php else: ?>

<div class="row g-3 mb-4">
    <div class="col-md-3 col-6">
        <div class="kpi">
            <div class="kpi-label">Registered Seniors</div>
            <div class="kpi-value"><?php echo e($totalSeniors); ?></div>
            <div class="kpi-icon"><i class="bi bi-people"></i></div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="kpi kpi-success">
            <div class="kpi-label">Total Claimed</div>
            <div class="kpi-value text-success"><?php echo e($totalClaimed); ?></div>
            <div class="kpi-icon"><i class="bi bi-check-circle"></i></div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="kpi kpi-warning">
            <div class="kpi-label">Unclaimed</div>
            <div class="kpi-value text-warning"><?php echo e($totalUnclaimed); ?></div>
            <div class="kpi-icon"><i class="bi bi-hourglass-split"></i></div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="kpi kpi-info">
            <div class="kpi-label">Amount Released</div>
            <div class="kpi-value" style="font-size:1.2rem">₱<?php echo e(number_format($totalAmount, 0)); ?></div>
            <div class="kpi-icon"><i class="bi bi-cash-stack"></i></div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-3 col-6">
        <div class="kpi">
            <div class="kpi-label">Payout Cycles</div>
            <div class="kpi-value"><?php echo e($totalCycles); ?></div>
            <div class="kpi-icon"><i class="bi bi-arrow-repeat"></i></div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="kpi">
            <div class="kpi-label">Barangays</div>
            <div class="kpi-value"><?php echo e($totalBarangays); ?></div>
            <div class="kpi-icon"><i class="bi bi-geo-alt"></i></div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="kpi">
            <div class="kpi-label">Counters</div>
            <div class="kpi-value"><?php echo e($totalCounters); ?></div>
            <div class="kpi-icon"><i class="bi bi-window-stack"></i></div>
        </div>
    </div>
    <div class="col-md-3 col-6">
        <div class="kpi kpi-danger">
            <div class="kpi-label">Cancelled</div>
            <div class="kpi-value text-danger"><?php echo e($totalCancelled); ?></div>
            <div class="kpi-icon"><i class="bi bi-x-circle"></i></div>
        </div>
    </div>
</div>


<div class="row g-3 mb-4">

    
    <div class="col-md-8">
        <div class="surface">
            <div class="surface-head">
                <h5><i class="bi bi-calendar3 me-2"></i>Transactions by Month</h5>
                <span class="text-muted" style="font-size:.75rem">Last 6 months</span>
            </div>
            <div class="surface-body p-0">
                <?php if($byMonth->isEmpty()): ?>
                    <div class="empty-state">
                        <i class="bi bi-calendar-x d-block"></i>
                        No transaction data yet.
                    </div>
                <?php else: ?>
                <div class="table-wrap" style="border-radius:0;border:0;box-shadow:none">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Month</th>
                                <th>Total</th>
                                <th>Claimed</th>
                                <th>Unclaimed</th>
                                <th>Amount Released</th>
                                <th>Claim Rate</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $byMonth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $rate = $row->total > 0 ? round(($row->claimed / $row->total) * 100) : 0;
                            ?>
                            <tr>
                                <td><strong><?php echo e($row->month); ?></strong></td>
                                <td><?php echo e($row->total); ?></td>
                                <td><span class="pill pill-success"><?php echo e($row->claimed); ?></span></td>
                                <td><span class="pill pill-warning"><?php echo e($row->unclaimed); ?></span></td>
                                <td>₱<?php echo e(number_format($row->amount_released, 2)); ?></td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div style="flex:1;height:6px;background:#e2e8f0;border-radius:99px;overflow:hidden">
                                            <div style="width:<?php echo e($rate); ?>%;height:100%;background:#047857;border-radius:99px"></div>
                                        </div>
                                        <span style="font-size:.72rem;color:#64748b;min-width:32px"><?php echo e($rate); ?>%</span>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="col-md-4">
        <div class="surface mb-3">
            <div class="surface-head">
                <h5><i class="bi bi-arrow-repeat me-2"></i>Active Cycles</h5>
            </div>
            <div class="surface-body">
                <?php $__empty_1 = true; $__currentLoopData = $activeCycles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cycle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span style="font-size:.82rem"><?php echo e($cycle->cycle_name); ?></span>
                    <a href="<?php echo e(route('payout-cycles.show', $cycle)); ?>" class="btn btn-sm btn-outline-secondary">View</a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-muted mb-0" style="font-size:.82rem">No active cycles.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="surface">
            <div class="surface-head">
                <h5><i class="bi bi-calendar-event me-2"></i>Upcoming Schedules</h5>
            </div>
            <div class="surface-body p-0">
                <?php $__empty_1 = true; $__currentLoopData = $upcomingSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div style="padding:.65rem 1.1rem;border-bottom:1px solid #eef2f7">
                    <div style="font-size:.82rem;font-weight:500"><?php echo e($schedule->barangay->name ?? 'No Barangay'); ?></div>
                    <div style="font-size:.72rem;color:#64748b">
                        <?php echo e($schedule->scheduled_date); ?>

                        <?php if($schedule->time_start): ?> · <?php echo e($schedule->time_start); ?> <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="empty-state" style="padding:1.5rem">No upcoming schedules.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<div class="surface">
    <div class="surface-head">
        <h5><i class="bi bi-geo-alt me-2"></i>Payout Summary by Barangay</h5>
        <a href="<?php echo e(route('barangays.index')); ?>" class="btn btn-sm btn-outline-secondary">View All</a>
    </div>
    <div class="surface-body p-0">
        <?php if($byBarangay->isEmpty()): ?>
            <div class="empty-state"><i class="bi bi-geo d-block"></i>No data yet.</div>
        <?php else: ?>
        <div class="table-wrap" style="border-radius:0;border:0;box-shadow:none">
            <table class="table">
                <thead>
                    <tr>
                        <th>Barangay</th>
                        <th>Total Seniors</th>
                        <th>Claimed</th>
                        <th>Unclaimed</th>
                        <th>Amount Released</th>
                        <th>Progress</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $byBarangay; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $rate = $row->total > 0 ? round(($row->claimed / $row->total) * 100) : 0;
                    ?>
                    <tr>
                        <td><strong><?php echo e($row->name); ?></strong></td>
                        <td><?php echo e($row->total ?: '—'); ?></td>
                        <td><span class="pill pill-success"><?php echo e($row->claimed); ?></span></td>
                        <td><span class="pill pill-warning"><?php echo e($row->unclaimed); ?></span></td>
                        <td>₱<?php echo e(number_format($row->amount_released, 2)); ?></td>
                        <td style="min-width:120px">
                            <div class="d-flex align-items-center gap-2">
                                <div style="flex:1;height:6px;background:#e2e8f0;border-radius:99px;overflow:hidden">
                                    <div style="width:<?php echo e($rate); ?>%;height:100%;background:#1d4ed8;border-radius:99px"></div>
                                </div>
                                <span style="font-size:.72rem;color:#64748b;min-width:32px"><?php echo e($rate); ?>%</span>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dell7\Documents\GitHub\seniorPayoutSystem\resources\views/dashboard.blade.php ENDPATH**/ ?>