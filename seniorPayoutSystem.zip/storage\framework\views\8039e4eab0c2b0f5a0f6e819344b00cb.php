<?php $__env->startSection('topbar-title', 'Schedules'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-head">
    <div>
        <div class="page-eyebrow">Payouts</div>
        <h2 class="page-title">Payout schedules</h2>
        <div class="page-sub">Per-barangay disbursement schedules.</div>
    </div>
    <div class="page-actions">
        <?php if(auth()->user()->role === 'admin'): ?>
        <a href="<?php echo e(route('payout-schedules.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> New schedule
        </a>
        <?php endif; ?>
    </div>
</div>

<div class="table-wrap">
    <table class="table">
        <thead>
            <tr>
                <th>Cycle</th>
                <th>Barangay</th>
                <th>Date</th>
                <th>Time</th>
                <th>Venue</th>
                <th class="text-end">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-muted"><?php echo e($schedule->cycle->cycle_name ?? '—'); ?></td>
                    <td class="fw-semibold"><?php echo e($schedule->barangay->name ?? '—'); ?></td>
                    <td><?php echo e($schedule->scheduled_date); ?></td>
                    <td>
                        <?php echo e($schedule->time_start ?? '—'); ?><?php if($schedule->time_end): ?> — <?php echo e($schedule->time_end); ?><?php endif; ?>
                    </td>
                    <td><?php echo e($schedule->venue ?? '—'); ?></td>
                    <td class="text-end">
                        <div class="row-actions">
                            <a href="<?php echo e(route('payout-schedules.show', $schedule)); ?>" class="row-action view" title="View"><i class="bi bi-eye"></i></a>
                            <?php if(auth()->user()->role === 'admin'): ?>
                            <a href="<?php echo e(route('payout-schedules.edit', $schedule)); ?>" class="row-action edit" title="Edit"><i class="bi bi-pencil"></i></a>
                            <form action="<?php echo e(route('payout-schedules.destroy', $schedule)); ?>" method="POST"
                                onsubmit="return confirm('Delete this schedule?')" class="d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="row-action delete" title="Delete"><i class="bi bi-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="table-empty">No schedules created yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-3">
    <?php echo e($schedules->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dell7\Documents\GitHub\seniorPayoutSystem\resources\views/payout-schedules/index.blade.php ENDPATH**/ ?>