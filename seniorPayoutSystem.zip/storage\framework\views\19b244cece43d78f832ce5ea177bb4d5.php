<?php $__env->startSection('topbar-title', 'Requirements'); ?>
<?php $__env->startSection('content'); ?>

<div class="page-head">
    <div>
        <div class="page-eyebrow">Operations</div>
        <h2 class="page-title">Document requirements</h2>
        <div class="page-sub">Required documents per payout cycle.</div>
    </div>
    <div class="page-actions">
        <?php if(auth()->user()->role === 'admin'): ?>
        <a href="<?php echo e(route('document-requirements.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i> Add requirement
        </a>
        <?php endif; ?>
    </div>
</div>

<div class="table-wrap">
    <table class="table">
        <thead>
            <tr>
                <th>Cycle</th>
                <th>Document</th>
                <th>Description</th>
                <th>Mandatory</th>
                <th class="text-end">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-muted"><?php echo e($req->cycle->cycle_name ?? '—'); ?></td>
                    <td class="fw-semibold"><?php echo e($req->document_name); ?></td>
                    <td class="text-muted"><?php echo e(Str::limit($req->description, 60) ?? '—'); ?></td>
                    <td>
                        <?php if($req->is_mandatory): ?>
                            <span class="pill pill-danger">Required</span>
                        <?php else: ?>
                            <span class="pill pill-muted">Optional</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-end">
                        <div class="row-actions">
                            <a href="<?php echo e(route('document-requirements.show', $req)); ?>"
                                class="row-action view" title="View">
                                <i class="bi bi-eye"></i>
                            </a>
                            <?php if(auth()->user()->role === 'admin'): ?>
                            <a href="<?php echo e(route('document-requirements.edit', $req)); ?>"
                                class="row-action edit" title="Edit">
                                <i class="bi bi-pencil"></i>
                            </a>
                            <form action="<?php echo e(route('document-requirements.destroy', $req)); ?>"
                                method="POST"
                                onsubmit="return confirm('Delete this requirement?')"
                                class="d-inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="row-action delete" title="Delete">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="table-empty">No document requirements set yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div class="mt-3">
    <?php echo e($requirements->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\dell7\Documents\GitHub\seniorPayoutSystem\resources\views/document-requirements/index.blade.php ENDPATH**/ ?>